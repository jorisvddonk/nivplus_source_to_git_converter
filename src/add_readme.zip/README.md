This is the entire revision history of Noctis IV Plus, starting with R0 (vanilla NIV) all the way up to R2.2b.
This repository has automatically been generated with [a fairly simple tool](https://github.com/jorisvddonk/nivplus_source_to_git_converter)

Please check elsewhere in this repository for more information.