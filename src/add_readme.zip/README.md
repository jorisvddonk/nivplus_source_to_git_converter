This is a partial revision history of the Noctis IV Starmap.

Please check elsewhere in this repository for more information.