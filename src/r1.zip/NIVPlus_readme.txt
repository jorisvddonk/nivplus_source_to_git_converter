Noctis IV+
A tiny mod by Megagun, including a fix by Shadowlord made in Noctis IV CE
-------------------
Noctis IV+ is Noctis IV, but:
ADD: 'm' is now an alias for taking a snapshot, and 'n' is now an alias for taking a panoramic shapshot
FIX: Panoramic snapshots don't bug up Noctis IV anymore
CHANGE: Speedup on the roof of the stardrifter is now enabled.